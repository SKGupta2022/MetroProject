﻿using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Interface.Repository
{
    public interface IRechargeRepository
    {
        Task<ApiResponse<CardDetails>> GetPendingAmount(string mobile);
    }
}
