﻿using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Interface.Repository
{
    public interface ICustomerRepository
    {
        Task<ApiResponse<UserDetails>> GetCustomer(LoginModel login);
        Task<ApiResponse<TransactionResponse>> PostCustomer(UserDetails user);
        Task<List<UserDetails>> GetAllCustomer();
    }
}
