﻿using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Interface.Repository
{
    public interface ILoginRepository
    {
        Task<ApiResponse<TransactionResponse>> UserValidate(LoginModel login);

        Task<OTP_Generate> Aadhar_Otp_Generate(string Aadhaar);

        Task<OTP_Generate> Aadhar_OTP_Authenticate(OtpAuthenticationParameter otpPara);
    }
}
