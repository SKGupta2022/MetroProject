﻿using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Interface.Services
{
    public interface IRechargeService
    {
        Task<ApiResponse<CardDetails>> GetPendingAmount(string mobile);
    }
}
