﻿using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Interface.Services
{
    public interface ICustomerService
    {
        Task<ApiResponse<TransactionResponse>> PostCustomer(UserDetails user);
        Task<ApiResponse<UserDetails>> GetCustomer(LoginModel login);

        Task<List<UserDetails>> GetAllCustomer();


    }
}
