﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class OtpAuthenticationParameter
    {
        public string Userotp { get; set; }
        public string txnid { get; set; }
        public string AadhaarID { get; set; }
        public string JanAadhaar { get; set; }
    }
}
