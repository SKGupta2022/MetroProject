﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class OTP_Generate
    {
        public string AadhaarId { get; set; }
        public string Mobile { get; set; }
        public string txnID { get; set; }
        public string Message { get; set; }
        public string TransactionID { get; set; }

        public string JanAadhaarId { get; set; }

        public string Basestring { get; set; }
    }
    public class Jan_AadhaarOtp_Auth : Base
    {
        public string Aadhaar { get; set; }
        public string UserOtp { get; set; }
        public string ResTxnid { get; set; }
        public string Message { get; set; }
        public string Basestring { get; set; }
        public string JanAadhaarId { get; set; }
        public double Amount { get; set; }
        public string DepartmentCommission { get; set; }
        public string EmitraCommission { get; set; }
    }

    public class Base
    {
        public string KioskCode { get; set; }
        public string MachineId { get; set; }
        public string SsoId { get; set; }
        public string ServiceId { get; set; }
        public string SubServiceId { get; set; }
        public string Mobile { get; set; }
    }
}
