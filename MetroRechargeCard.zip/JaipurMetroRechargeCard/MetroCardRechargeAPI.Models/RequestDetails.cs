﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class RequestDetailsModel
    {
        public string USERNAME { get; set; }
        public string USEREMAIL { get; set; }
        public string USERMOBILE { get; set; }
        public string PURPOSE { get; set; }
        public string AMOUNT { get; set; }
        public string PRN { get; set; }
    }
}
