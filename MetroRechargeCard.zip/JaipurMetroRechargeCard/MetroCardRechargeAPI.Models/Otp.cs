﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class OTP
    {
        public string MobileNumber { get; set; }
        public int _OTP { get; set; }
        public long ReferenceNumber { get; set; }
        public DateTime createdOn { get; set; }
        public string encryptedCreatedOn { get; set; }
        public string encryptedMobile { get; set; }
        public string encryptedID { get; set; }
        public string selectedRadioButton { get; set; }
    }
}
