﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class OTPResponseModel
    {
        public string status { get; set; }
        public string err { get; set; }
        public string tid { get; set; }
    }

    public class OTPRequest
    {
        public OTPRequestModel OTPRequestModel { get; set; }
    }
    public class OTPRequestModel
    {
        public string janaadharId { get; set; }
        public string mid { get; set; }
        public string schemeId { get; set; }
    }
}
