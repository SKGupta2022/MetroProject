﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class JanAadhaarResponse
    {
        public string familyId { get; set; }
        public string ecard { get; set; }
        public string jayId { get; set; }
        public string status { get; set; }

    }
}
