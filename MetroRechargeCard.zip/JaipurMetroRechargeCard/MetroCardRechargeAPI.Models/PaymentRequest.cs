﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class PaymentRequest
    {
        public string MERCHANTCODE { get; set; }
        public RequestParameters REQUESTPARAMETERS { get; set; }
        public string REQUESTJSON { get; set; }
        public string ENCDATA { get; set; }
    }
}
