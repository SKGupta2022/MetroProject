﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Models
{
    public class RechargeAmtModel
    {
        public List<RechargeColumn> lstRechargeOptions = new List<RechargeColumn>
            {
                new RechargeColumn{Text="100", Value="100"},
                new RechargeColumn{Text="200", Value="200"},
                new RechargeColumn{Text="300", Value="300"},
                new RechargeColumn{Text="400", Value="400"},
                new RechargeColumn{Text="500", Value="500"},
                new RechargeColumn{Text="600", Value="600"},
                new RechargeColumn{Text="700", Value="700"},
                new RechargeColumn{Text="800", Value="800"},
                new RechargeColumn{Text="900", Value="900"},
                new RechargeColumn{Text="1000", Value="1000"}
            };
        public List<RechargeColumn> lstRechargeAmount { get; set; }
        public int SelectRechargeOption { get; set; }
    }

    public class RechargeColumn
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
