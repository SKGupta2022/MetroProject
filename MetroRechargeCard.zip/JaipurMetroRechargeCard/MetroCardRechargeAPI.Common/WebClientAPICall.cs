﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Common
{
    public static class WebClientAPICall
    {
        public static async Task<string> CallApi(string apiUrl, string apiName, string parameter)
        {
            string strResponse = string.Empty;

            Uri u = new Uri(apiUrl + apiName + parameter);
            var payload = "";

            HttpContent c = new StringContent(payload, Encoding.UTF8, "application/json");
            strResponse = await SendURI(u, c);

            return strResponse;
        }

        public static async Task<string> CallApiJson(string apiUrl, string apiName, string parameter)
        {
            string strResponse = string.Empty;

            Uri u = new Uri(apiUrl + apiName);
            var payload = parameter;

            HttpContent c = new StringContent(payload, Encoding.UTF8, "application/json");
            strResponse = await SendURI(u, c);

            return strResponse;
        }

        private static async Task<string> SendURI(Uri u, HttpContent c)
        {
            var response = string.Empty;
            using (var client = new HttpClient())
            {
                HttpRequestMessage request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = u,
                    Content = c
                };

                HttpResponseMessage result = await client.SendAsync(request);
                var responseContent = await result.Content.ReadAsStringAsync();
                response = responseContent;
            }
            return response;
        }

        public static async Task<string> CallApi(string apiUrl, string apiName)
        {
            string strResponse = string.Empty;

            Uri u = new Uri(apiUrl + apiName);
            var payload = "";

            HttpContent c = new StringContent(payload, Encoding.UTF8, "application/json");
            strResponse = await SendURI(u, c);

            return strResponse;
        }


        public static async Task<string> PostURI(Uri u, HttpContent c)
        {
            var response = string.Empty;
            using (var client = new HttpClient())
            {
                HttpRequestMessage request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = u,
                    Content = c
                };

                HttpResponseMessage result = await client.SendAsync(request);
                var responseContent = await result.Content.ReadAsStringAsync();
                response = responseContent;
            }
            return response;
        }
    }
}
