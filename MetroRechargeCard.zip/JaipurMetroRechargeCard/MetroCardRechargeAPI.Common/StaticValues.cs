﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Common
{
    public class StaticValues
    {

        public static string Chiranjeevi = "Some Error Occured.Please Try Again. ";
        public static string KycVerification = "Your Bio-Kyc Is Successfull. ";
        public static string KycVerificationN = "Your Bio-Kyc Is Not Done, Please Try Again. ";
        public static string AlreadyExist = "You Have Already Marked Your Attendance In Same Day.";
        public static string Failed = "You Are Not Authenticate Person To Mark Attendance!";
        public static string LSPDepartment = "153";
        public static string LSPOrgainisationID = "1801";
        public static string LSPDesignationID = "7797";
        public static string AttendanceServiceID = "4570";
        public static string UpdateMobileServiceID = "6350";
        public static string UpdateAccountServiceID = "7710";//6350//update bank account serviceid 7710 ,5710
        public static string UpdateAccountSubServiceID = "7153";//update bank account Subserviceid
        public static string KYCServiceID = "5930";
        public static string PalanHaarServiceId = "8011";
        public static string ChiranjeeviServiceID = "7772";
        public static string RajSspServiceId = "1940";
        public static string RequestType = "4";
        public static string Category1_LSP = "{0}-{1}-{2}-{3}-{4}-{5}-{6}-{7}-{8}-{9}";//{0}DateTime{1}MachineKioskCode{2}CoOrdinaterTypeId{3}ShortNameTile{4}LSP{5}CompanyName{6}EmployeeId{7}SsoId{8}MachineSerialNumber{9}LSP
        public static string Category1_Other = "{0}-{1}-{2}-{3}";//{0}DateTime{1}EmployeeID{2}MachineNumber{3}N
        public static string Category2 = "{0}-{1}-{2}-{3}-{4}";//{0}DateTime{1}MachineKioskCode{2}SsoId{3}MachineSerialNumber{4}NI or NB;
        public static string timestamp = "yyyyMMddHHmmssfff";
        public static string PaymentStatusPGLive = "https://emitraapp.rajasthan.gov.in/aggregator/api/payment/status";
        public static string PaymentStatusPGLocal = "http://emitrauat.rajasthan.gov.in/aggregator/api/payment/status";
        public static string SsoVerification = "SSOVERIFICATION";
        //public static string timestamps = DateTime.Now.ToString("yyyyMMddHHmmssfff");    
    }
}
