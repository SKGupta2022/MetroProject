﻿using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Common
{
    public class callfunction
    {
        public static string GetEncryptedPIDXmlNew(string pidXml, string ts, ref string certExpiryDate, ref string encSessionKey, ref string encHmac)
        {
            ENCRYPTER enc = new ENCRYPTER();
            byte[] pidXmlBytes = Encoding.UTF8.GetBytes(pidXml);
            byte[] session_key = enc.generateSessionKey();
            byte[] encrypted_skey = enc.encryptUsingPublicKey(session_key);
            byte[] encPidXmlBytes = enc.encryptUsingSessionKeyNew(session_key, pidXmlBytes, ts, false);
            byte[] hmac = enc.generateSha256Hash(pidXmlBytes);
            byte[] encHmacBytes = enc.encryptUsingSessionKeyNew(session_key, hmac, ts, true);
            encSessionKey = Convert.ToBase64String(encrypted_skey);
            encHmac = Convert.ToBase64String(encHmacBytes);
            certExpiryDate = enc.getCertificateIdentifier();
            return Convert.ToBase64String(encPidXmlBytes);
        }

        public class ENCRYPTER
        {
            private const string ASYMMETRIC_ALGO = "RSA/ECB/PKCS1Padding";
            private const int SYMMETRIC_KEY_SIZE = 256;
            private DateTime certExpiryDate;
            private RsaKeyParameters publicKey;
            public static int IV_SIZE_BITS = 96;
            // Additional authentication data - last 128 bits of ISO format timestamp
            public static int AAD_SIZE_BITS = 128;
            // Authentication tag length - in bits
            public static int AUTH_TAG_SIZE_BITS = 128;


            public ENCRYPTER()
            {
                try
                {
                    string Certificate = @"-----BEGIN CERTIFICATE-----
MIIFujCCBKKgAwIBAgIEARH+GDANBgkqhkiG9w0BAQsFADCBkDELMAkGA1UEBhMC
SU4xKjAoBgNVBAoTIWVNdWRocmEgQ29uc3VtZXIgU2VydmljZXMgTGltaXRlZDEd
MBsGA1UECxMUQ2VydGlmeWluZyBBdXRob3JpdHkxNjA0BgNVBAMTLWUtTXVkaHJh
IFN1YiBDQSBmb3IgQ2xhc3MgMyBPcmdhbmlzYXRpb24gMjAxNDAeFw0xOTEwMjIx
MzUwMTJaFw0yMjEwMjExMzUwMTJaMIG+MQswCQYDVQQGEwJJTjEOMAwGA1UEChMF
VUlEQUkxGjAYBgNVBAsTEVRlY2hub2xvZ3kgQ2VudHJlMQ8wDQYDVQQREwY1NjAw
OTIxEjAQBgNVBAgTCUtBUk5BVEFLQTFJMEcGA1UEBRNAODdiNzU2ZjQ5ZWZlY2Jh
MTczNzllOTY5N2JhMmNmMzFkYTdlOGY4NGE2ZThmNGRhOGQwNWIxODNmYjVkMWFk
OTETMBEGA1UEAxMKQU5VUCBLVU1BUjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
AQoCggEBAKsLzL3ZBNu4Czfqa7XarC63uphHTc/mWnDAKHZ0Dh8mBGVb+xeM8zVS
9y6VLsciBZ/O6/qXQwfefWyjL2MLt/0LpEE4cG7VLV1C9OYK6y2MbrT9nwzN+pAM
zcWTNiiee6W6LaKjXcOqs3Dzgzd19KW1Zk5U6blISRH5NCQ83srTAPMll1xMkzbf
PCluvYlR7RtODyNQP5EwvuTncpAVi+7r1weV431LvjeuDajDfV494knt/5XkJha5
7MtfzeuQbVXfHzHTgkubcpCjSjMHhxOeBisjtcFtrTi4K2RQ5njWEkvAyXSmDWb1
XJx6w+p69ezN9KqwJubbShzd9PVixZcCAwEAAaOCAeowggHmMCIGA1UdEQQbMBmB
F2FudXAua3VtYXJAdWlkYWkubmV0LmluMBMGA1UdIwQMMAqACEzRvSoRSATTMB0G
A1UdDgQWBBRgl7mQb3UttrwwwusTkidEbBmwyzAMBgNVHRMBAf8EAjAAMA4GA1Ud
DwEB/wQEAwIFIDAZBgNVHSUBAf8EDzANBgsrBgEEAYI3CgMEATCBjAYDVR0gBIGE
MIGBMC0GBmCCZGQCAzAjMCEGCCsGAQUFBwICMBUaE0NsYXNzIDMgQ2VydGlmaWNh
dGUwUAYHYIJkZAEIAjBFMEMGCCsGAQUFBwIBFjdodHRwOi8vd3d3LmUtbXVkaHJh
LmNvbS9yZXBvc2l0b3J5L2Nwcy9lLU11ZGhyYV9DUFMucGRmMHsGCCsGAQUFBwEB
BG8wbTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZS1tdWRocmEuY29tMEUGCCsG
AQUFBzAChjlodHRwOi8vd3d3LmUtbXVkaHJhLmNvbS9yZXBvc2l0b3J5L2NhY2Vy
dHMvQzNPU0NBMjAxNC5jcnQwRwYDVR0fBEAwPjA8oDqgOIY2aHR0cDovL3d3dy5l
LW11ZGhyYS5jb20vcmVwb3NpdG9yeS9jcmxzL0MzT1NDQTIwMTQuY3JsMA0GCSqG
SIb3DQEBCwUAA4IBAQBMONK4yQPA9QPSwaSPsSygegmLAbAnWxZVeKF7iARnRj2e
KvC4kPP9fB+ZjeHnsPAbjRO3lLSKdqctMGCsQlbVwrnHKYhEdMHADwd1Q84bUwZf
CKfPVkz7A1pky/SNyCWsuFqo1YplmBJxHLO7PKiTpt15K+MqOrZI1FLyzDfh5DSd
g77YqUkqbgcqBjuiH7Zc8EtYj76olOXn+B4PHtZi5BG4IvGV+f/WtnHGLi700461
CgAWQ59/TzCsESmOpfAUpAlSBhKUamR/YhikeBG0kncxzPLOm+A8Thi2mZhSo6Jo
V+YRES1dPFxXa2c4/iD7RG1uHghzIz+vF4dQHNrF
-----END CERTIFICATE-----";
                    byte[] bytes = Encoding.ASCII.GetBytes(Certificate);
                    Org.BouncyCastle.X509.X509Certificate x509Certificate = new X509CertificateParser().ReadCertificate(bytes);
                    this.publicKey = (RsaKeyParameters)x509Certificate.GetPublicKey();
                    this.certExpiryDate = x509Certificate.NotAfter;

                }
                catch (Exception innerException)
                {
                    throw new Exception("Could not intialize encryption module", innerException);
                }
                finally
                {
                    // if (fileStream != null) { fileStream.Close(); }
                }
            }

            public ENCRYPTER(byte[] publicKeyBytes)
            {
                try
                {
                    Org.BouncyCastle.X509.X509Certificate x509Certificate = new X509CertificateParser().ReadCertificate(publicKeyBytes);
                    this.publicKey = (RsaKeyParameters)x509Certificate.GetPublicKey();
                    this.certExpiryDate = x509Certificate.NotAfter;
                }
                catch (Exception innerException)
                {
                    throw new Exception("Could not intialize encryption module", innerException);
                }
            }

            public byte[] generateSessionKey()
            {
                SecureRandom random = new SecureRandom();
                KeyGenerationParameters parameters = new KeyGenerationParameters(random, 256);
                CipherKeyGenerator keyGenerator = GeneratorUtilities.GetKeyGenerator("AES");
                keyGenerator.Init(parameters);
                return keyGenerator.GenerateKey();
            }

            public byte[] encryptUsingPublicKey(byte[] data)
            {
                IBufferedCipher cipher = CipherUtilities.GetCipher("RSA/ECB/PKCS1Padding");
                cipher.Init(true, this.publicKey);
                return cipher.DoFinal(data);
            }

            public byte[] encryptUsingSessionKeyNew(byte[] skey, byte[] data, string ts, bool isHmac)
            {
                byte[] tsBytes = null;
                try
                {
                    tsBytes = Encoding.UTF8.GetBytes(ts);
                    byte[] ivBytes = new byte[IV_SIZE_BITS / 8];
                    byte[] aadBytes = new byte[AAD_SIZE_BITS / 8];
                    Array.Copy(tsBytes, tsBytes.Length - 12, ivBytes, 0, ivBytes.Length);
                    Array.Copy(tsBytes, tsBytes.Length - 16, aadBytes, 0, aadBytes.Length);

                    var cipher = new GcmBlockCipher(new AesFastEngine());
                    var parameters = new AeadParameters(new KeyParameter(skey), AUTH_TAG_SIZE_BITS, ivBytes, aadBytes);
                    cipher.Init(true, parameters);
                    byte[] result = new byte[cipher.GetOutputSize(data.Length)];
                    int processLen = cipher.ProcessBytes(data, 0, data.Length, result, 0);
                    cipher.DoFinal(result, processLen);
                    if (isHmac) return result;
                    // With Add for Session Key Encryption
                    byte[] packedCipherData = new byte[result.Length + tsBytes.Length];
                    Array.Copy(tsBytes, 0, packedCipherData, 0, tsBytes.Length);
                    Array.Copy(result, 0, packedCipherData, tsBytes.Length, result.Length);
                    return packedCipherData;
                }
                catch { throw; }
            }

            public byte[] generateSha256Hash(byte[] message)
            {
                IDigest digest = new Sha256Digest();
                digest.Reset();
                byte[] array = new byte[digest.GetDigestSize()];
                digest.BlockUpdate(message, 0, message.Length);
                digest.DoFinal(array, 0);
                return array;
            }

            public string getCertificateIdentifier()
            {
                return this.certExpiryDate.ToString("yyyyMMdd");
            }
        }
    }
}
