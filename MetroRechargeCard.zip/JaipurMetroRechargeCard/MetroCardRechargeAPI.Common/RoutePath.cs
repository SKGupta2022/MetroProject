﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Common
{
    public static class RoutePath
    {
        #region "LOGIN"
        public const string GetUserByMobile = "GetUserByMobile";
        public const string MetroUserValidate = "MetroUserValidate";
        public const string LoginValidate = "LoginValidate";
        public const string PostCustomer = "PostCustomer";
        public const string GetCustomer = "GetCustomer";
        #endregion

    }
}
