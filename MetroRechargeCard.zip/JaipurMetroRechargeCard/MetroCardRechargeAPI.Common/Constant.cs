﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetroCardRechargeAPI.Common
{
    public class Constants
    {
        public class ECARD
        {
            public static string AadhaarJanAadhaarAmount = "0";
            public static string AadhaarJanAadhaarEmitraCommission = "10";
            public static string SUBAUA = "PMITR22855";//PMITR22855//PRAVL22868
            public static string appname = "Emitra+";
            public static string authMode = "EKYC";
            public static string strlk = "MN9sIcmM8uVpxHEzSujPYjE5ROvkHjq4YKBHgPFxSafo8tr7wDpoW_E";//new license key 21-03-2023
            public static string WADH = "DEL9Vn2tNcxY/T3g9Jf6F/0Ne43ufdO6AaBClCWkCiQ=";
            public static string WADH1 = "QUp87pdfuV9Hjv9j/iJnsm+kSMFJcoobVqEVUvHgXdQ=";
            public static string dtTime = "2019";
            public static string client_id = "189a0b97-e3c8-4a01-8d9a-3f2f2d067f3b";
            public static string CLIENTID_UID_PROD = "9063b7b2-3a8d-4efb-8422-0572fff44ab2";
            public static string scheme = "eplus";
            public static string SERVICEPROVIDERNAME = "Updation of Mobile Number in Jan Adhaar Card";
            public static string SERVICEPROVIDERID = "6350";
            public static string SERVICEID = "5650";
            public static string PVCSERVICEID = "4488";
            public static string JanAadhaarPvc = "6293";
            public static string BirthPvc = "3021";
            public static string updateFlag = "MV";
            public static string updateFlagMU = "M";
            public static string updateFlagAU = "A";
            public static string updateFlagAV = "AV";
            public static string UserName = "eMitraPlusOTP";
            public static string Password = "eMtr@pl$0Tp#";
            public static string AadhaarUrl = "https://api.sewadwaar.rajasthan.gov.in/app/live/Aadhaar/Prod/detokenizeV2/doitAadhaar/encDec/demo/hsm/auth?client_id=d0c0a3e0-0897-4c1c-93f8-b61245923cc0";//9063b7b2-3a8d-4efb-8422-0572fff44ab2"
            public static string RequestUrl = "https://api.sewadwaar.rajasthan.gov.in/app/live/eSanchar/Prod/Service/api/OBD/CreateOTP/Request?client_id=9063b7b2-3a8d-4efb-8422-0572fff44ab2";
            public static string url1 = "https://api.sewadwaar.rajasthan.gov.in/app/live/Janaadhaar/Prod/Service/action/fetchJayFamily/";
            public static string url = "https://api.sewadwaar.rajasthan.gov.in/app/live/Janaadhaar/Prod/Service/ECARD/Id?jayId=";
            public static string authURL = "https://api.sewadwaar.rajasthan.gov.in/app/live/was/kyc/bio/prod?client_id=9063b7b2-3a8d-4efb-8422-0572fff44ab2";//SAME                                 
            public static string authURL1 = "https://api.sewadwaar.rajasthan.gov.in/app/live/was/otp/request/prod?client_id=9063b7b2-3a8d-4efb-8422-0572fff44ab2";//WAS Prod SAME                                             
            public static string authURL2 = "https://api.sewadwaar.rajasthan.gov.in/app/live/was/otp/auth/prod?client_id=9063b7b2-3a8d-4efb-8422-0572fff44ab2";
            public static string fetchdetails = "https://api.sewadwaar.rajasthan.gov.in/app/live/Janaadhaar/Prod/Service/action/kioskPlusFetchDtl/";
            public static string URL_BHAMASHAH_MOBACC_NO_UPDATE_PROD = "https://api.sewadwaar.rajasthan.gov.in/app/live/Janaadhaar/Prod/Service/action/kioskPlusPushDtl/";
            public static string param2 = "&authMode=" + authMode + "&dtTime=" + dtTime + "&scheme=" + scheme + "&client_id=" + client_id;
            public static string param = "?client_id=" + client_id + "&authMode=" + authMode + "&dtTime=" + dtTime + "&scheme=" + scheme;
            public static string Success = "Mobile Number Has Been Updated.";
            public static string Duplicate = "The mobile number, you are trying to update, already exists.Your transaction will be cancelled soon.";
            public static string Failed = "There's a problem in network, please try again.";
            public static string Null = "Some Error Occured,Please Try Again.";
            public static string Apierror = "Failed to establish a backside connection.";//Service Not Responding Please try again.
            public static string Aerror = "Error in parameter,So Account Number Has Not Been Updated.";
            public static string ASuccess = "Account Number Has Been Updated.";
            public static string AFailed = "Account Number Has Not Been Updated.Please Enter Correct IFSC CODE.";
            public static string JanaadhaarMessage = "No Record Found With The Given JanAadhaar/Aadhaar Number.";
            public static string JanaadhaarMessage1 = "Success";
            public static string RechargePurpose = "Metro Card Recharge";
        }

        public class JMRC
        {
            public static string RechargePurpose = "Metro Card Recharge";
        }
    }
}
