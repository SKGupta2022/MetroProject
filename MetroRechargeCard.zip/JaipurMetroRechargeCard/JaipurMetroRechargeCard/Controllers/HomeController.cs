﻿using JaipurMetroRechardCard.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace JaipurMetroRechardCard.Controllers
{
    public class HomeController : BaseController
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //if (!IsAuthicatePerson())
            //    return RedirectToAction("index", "login");

            return View();
        }

        //public IActionResult Payment()
        //{
        //    return RedirectToAction("PaymentRequest", "Payment");
        //}


        //public IActionResult Privacy()
        //{
        //    return RedirectToAction("PaymentRequest", "Payment");
        //}

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
