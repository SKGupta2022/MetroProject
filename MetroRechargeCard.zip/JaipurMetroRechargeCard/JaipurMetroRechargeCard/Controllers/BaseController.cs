﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JaipurMetroRechardCard.Controllers
{
    public class BaseController : Controller
    {

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {

        }
        
        // Login Authenticated Persion Only
        public bool IsAuthicatePerson()
        {
            var userId = HttpContext.Session.GetString("LoginUser");
            var otp = HttpContext.Session.GetString("Otp");
            if (userId != null && otp != null)
                return true;
            else 
                return false;
        }
    }
}
