﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JaipurMetroRechardCard.Controllers
{
    public class MetroRechargeReceiptController : BaseController
    {
        public IActionResult Index()
        {
            if (!IsAuthicatePerson())
                return RedirectToAction("index", "login");

            return View();
        }
    }
}
