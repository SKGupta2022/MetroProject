﻿using JaipurMetroRechardCard.Models;
using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Interface.Services;
using MetroCardRechargeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static MetroCardRechargeAPI.Common.ShowAlertHelper;

namespace JaipurMetroRechardCard.Controllers
{
    public class LoginController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILoginService _loginService = null;
        public LoginController(IHttpContextAccessor httpContextAccessor, ILoginService loginService)
        {
            _loginService = loginService;
            this._httpContextAccessor = httpContextAccessor;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(LoginModel login)
        {


            if (ModelState.IsValid)
            {
                ApiResponse<TransactionResponse> response = null;
                var validUser = new ValidateUser();
                response = await _loginService.UserValidate(login);
                if (response != null)
                {
                    TempData["Mobile"] = login.Mobile;
                    TransactionResponse transaction = new TransactionResponse();
                    transaction = response.Response;
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        if (transaction.AlertType == (int)Alerts.Success)
                        {
                            HttpContext.Session.SetString("LoginUser", login.Mobile);
                            HttpContext.Session.SetString("Otp", "1234");
                            return this.RedirectToAction("index", "Dashboard");
                        }
                        else
                        {
                            ViewBag.Alert = ShowAlertHelper.ShowAlert(Alerts.Info, transaction.TransResponse);
                        }
                    }
                    else
                    {
                        ViewBag.Alert = ShowAlertHelper.ShowAlert(Alerts.Danger, transaction.TransResponse);
                    }
                }
            }
            return View();
        }

        #region Adharnumber based OTP Generation and Varify
        public async Task<IActionResult> Otp_Generate(OTP_Generate otp_generate)
        {
            // Generate  Otp basis on Adharnumber
            //OTP_Generate records = new OTP_Generate();
            //records = await _loginService.Otp_Generate("640196021830");

            // Varify Otp basis on Adharnumber
            OtpAuthenticationParameter otpParameter = new OtpAuthenticationParameter() { AadhaarID = "640196021830", Userotp = "509692", txnid = "DOITRJGOVAUTH202209301734139412434" };
            OTP_Generate varifyOtp = await _loginService.Aadhar_OTP_Authenticate(otpParameter);


            OTP_Generate records = new OTP_Generate();
            records = await _loginService.Aadhar_Otp_Generate(otp_generate.AadhaarId);
            return View();
        }
        #endregion


    }

}
