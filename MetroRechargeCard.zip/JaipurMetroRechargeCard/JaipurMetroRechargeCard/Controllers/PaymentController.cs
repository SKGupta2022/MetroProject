﻿using JaipurMetroRechardCard.Models;
using MetroCardRechargeAPI.Interface.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static JaipurMetroRechardCard.Models.Payment;

namespace JaipurMetroRechardCard.Controllers
{
    public class PaymentController : BaseController
    {
        const string MERCHANTCODE = "rppTestMerchant";
        const string CHECKSUMKEY = "UWf6a7cDCP";
        IRechargeCardService _rechargeCardService = null;
        public PaymentController(IRechargeCardService rechargeCardService)
        {
            _rechargeCardService = rechargeCardService;
        }
        public async Task<IActionResult> PaymentRequest()
        {
            if (!IsAuthicatePerson())
                return RedirectToAction("index", "login");

            // retrieve value from request object
            RequestDetails request = new RequestDetails();
            MetroCardRechargeAPI.Models.RechargeModel recharge = new MetroCardRechargeAPI.Models.RechargeModel();
            string requestdata = "";
            if (TempData["data"] != null)
                requestdata = (string)TempData["data"];
            request = JsonConvert.DeserializeObject<RequestDetails>(requestdata);

            // Generate PRN
            Random rnd = new Random();
            string PRN = "PRN" + rnd.Next(100000, 999999);

            // Save Request
            var respone = await _rechargeCardService.SaveRequest(requestdata, PRN);
            // generate randon number 


            // send request
            PaymentRequest PAYMENTREQUEST = PaymentHelper.SendRequest(PRN, request.AMOUNT, request.PURPOSE, request.USERNAME, request.USERMOBILE, request.USEREMAIL);
            return View("PostRequest", PAYMENTREQUEST);
        }

        public string Get(string key)
        {
            return Request.Cookies[key];
        }

        public async Task<IActionResult> PaymentResponse()
        {
            //if (!IsAuthicatePerson())
            //    return RedirectToAction("index", "login");

            PaymentResponse paymentResponse = new PaymentResponse();
            string Status = Request.Form["STATUS"];
            string EncData = Request.Form["ENCDATA"];
            TempData["STATUS"] = Status;
            TempData["ENCDATA"] = EncData;
            MetroCardRechargeAPI.Models.RechargeModel recharge = new MetroCardRechargeAPI.Models.RechargeModel();
            paymentResponse = PaymentHelper.GetResponse(Status, EncData);
            if (paymentResponse != null)
            {
                string rechargedata = Get("recharge");
                if (rechargedata != null)
                    recharge = JsonConvert.DeserializeObject<MetroCardRechargeAPI.Models.RechargeModel>(rechargedata);

                recharge.PaymentTransDetails = new MetroCardRechargeAPI.Models.PaymentResponse();
                recharge.PaymentTransDetails.CHECKSUMVALID = paymentResponse.CHECKSUMVALID;
                recharge.PaymentTransDetails.ENCDATA = paymentResponse.ENCDATA;
                recharge.PaymentTransDetails.RESPONSEJSON = paymentResponse.RESPONSEJSON;
                recharge.PaymentTransDetails.STATUS = paymentResponse.STATUS;
                var responseparametersJson = JsonConvert.SerializeObject(paymentResponse.RESPONSEPARAMETERS);
                recharge.PaymentTransDetails.ResponseParameterJson = responseparametersJson;
                var respone = await _rechargeCardService.AddRecharge(recharge);
            }
            return View("PaymentResponse", paymentResponse);
        }

        public IActionResult MetroRechargeReceipt()
        {
            string Status = string.Empty;
            string EncData = string.Empty;

            if (TempData["STATUS"] == null)
                Status = Request.Form["STATUS"];
            else
                Status = TempData["STATUS"].ToString();

            if (TempData["ENCDATA"] == null)
                EncData = Request.Form["ENCDATA"];
            else
                EncData = TempData["ENCDATA"].ToString();
            var userDetailJson = Get("User");
            InvoiceParameter invoicePara = (InvoiceParameter)JsonConvert.DeserializeObject<InvoiceParameter>(Get("User"));
            var paymentResponse = PaymentHelper.GetResponse(Status, EncData);
            ResponeParameter responsePara = new ResponeParameter();
            if (paymentResponse != null)
                responsePara = JsonConvert.DeserializeObject<ResponeParameter>(paymentResponse.RESPONSEJSON);
            invoicePara.Status = Status;
            invoicePara.responseParameter = responsePara;
            invoicePara.rechargeDetails.Invoice_Date = DateTime.Now;
            return View("MetroRechargeReceipt", invoicePara);
        }

    }
}
