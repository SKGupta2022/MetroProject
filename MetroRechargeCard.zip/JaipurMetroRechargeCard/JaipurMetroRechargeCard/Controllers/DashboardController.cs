﻿using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Interface.Services;
using MetroCardRechargeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JaipurMetroRechardCard.Controllers
{
    public class DashboardController : BaseController
    {
        ICustomerService _customerService = null;

        public DashboardController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        public async Task<IActionResult> Index()
        {
            if (!IsAuthicatePerson())
                return RedirectToAction("index", "login");

            UserDetails data = new UserDetails();
            UserModel userModel = new UserModel();
            RechargeModel rechargeModel = new RechargeModel();
            string mobile = "";
            if (TempData["Mobile"] != null)
                mobile = TempData["Mobile"] as string;
            else
                mobile = GetMobile();

            LoginModel login = new LoginModel { Mobile = mobile };
            ApiResponse<UserDetails> respone = await _customerService.GetCustomer(login);
            if (respone != null)
            {
                if (respone.Response != null)
                    data = respone.Response;
                Adddress modelAddess = new Adddress
                {
                    fullAddress = data.Address,
                    City = data.City,
                    State = data.State,
                    Country = data.Country,
                    Pincode = data.Pincode
                };
                RechargeDetails rechargeDetails = new RechargeDetails();
                rechargeDetails.CardNo = data.cardDetails.CardNo;
                UserModel model = new UserModel()
                {
                    UserName = data.Name,
                    UserMail = data.Email,
                    UserMobile = data.Mobile,
                    Purpose = Constants.JMRC.RechargePurpose,
                    address = modelAddess,
                    rechargeDetails = rechargeDetails

                };
                string jsonData = JsonConvert.SerializeObject(model);
                CookieOptions cookieOptions = new CookieOptions();
                cookieOptions.Path = "/";
                cookieOptions.Expires = new DateTimeOffset(DateTime.Now.AddDays(7));
                HttpContext.Response.Cookies.Append("User", jsonData, cookieOptions);
            }
            if (data != null)
            {
                TempData["CustId"] = data.CustCode as string;
            }
            return View(data);
        }

        public void Set(string key, string value, int? expireTime)
        {
            CookieOptions option = new CookieOptions();
            if (expireTime.HasValue)
                option.Expires = DateTime.Now.AddMinutes(expireTime.Value);
            else
                option.Expires = DateTime.Now.AddMilliseconds(10);
            Response.Cookies.Append(key, value, option);
        }
        public string Get(string key)
        {
            return Request.Cookies[key];
        }

        public string GetMobile()
        {
            string cookiedata = Get("User");
            string mobile = "";
            UserModel userModel = new UserModel();
            if (cookiedata != null)
            {
                userModel = JsonConvert.DeserializeObject<UserModel>(cookiedata);
            }

            if (userModel != null)
            {
                MetroCardRechargeAPI.Models.RechargeModel recharge = new MetroCardRechargeAPI.Models.RechargeModel()
                {
                    Mobile = userModel.UserMobile,
                };
                mobile = recharge.Mobile;
            }
            return mobile;
        }

    }
}
