﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MetroCardRechargeAPI.Models;
using JaipurMetroRechardCard.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Interface.Services;

namespace JaipurMetroRechardCard.Controllers
{
    public class RechargeController : BaseController
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IRechargeService _rechargeService = null;
        public RechargeController(IHttpContextAccessor httpContextAccessor, IRechargeService rechargeService)
        {
            _httpContextAccessor = httpContextAccessor;
            _rechargeService = rechargeService;
        }

        public async Task<IActionResult> Index()
        {
            string mobile = GetMobile();
            ApiResponse<CardDetails> card = await _rechargeService.GetPendingAmount(mobile);
            if (card != null && card.Response != null)
            {
                ViewBag.PendingAmt = card.Response.PendingAmt;
            }
            RechargeAmtModel model = new RechargeAmtModel();
            model.lstRechargeAmount = model.lstRechargeOptions;
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(RechargeAmtModel model)
        {
            TempData["rechageAmt"] = model.SelectRechargeOption;
            return this.RedirectToAction("RechargeDetail");
        }

        public string GetMobile()
        {
            string cookiedata = Get("User");
            string mobile="";
            UserModel userModel = new UserModel();
            if (cookiedata != null)
            {
                userModel = JsonConvert.DeserializeObject<UserModel>(cookiedata);
            }

            if (userModel != null)
            {
                MetroCardRechargeAPI.Models.RechargeModel recharge = new MetroCardRechargeAPI.Models.RechargeModel()
                {
                    Mobile = userModel.UserMobile,
                };
                mobile = recharge.Mobile;
            }
            return mobile;
        }


        public async Task<IActionResult> RechargeDetail()
        {
            string mobile = GetMobile();
            ApiResponse<CardDetails> card = await _rechargeService.GetPendingAmount(mobile);
            if (card != null && card.Response != null)
            {
                ViewBag.PendingAmt = card.Response.PendingAmt;
            }

            UserDetails userDetails = new UserDetails();
            int rechargeAmt = (int)TempData["rechageAmt"];
            string cookiedata = Get("User");
            UserModel userModel = new UserModel();
            if (cookiedata != null)
            {
                userModel = JsonConvert.DeserializeObject<UserModel>(cookiedata);
            }

            if (userModel != null)
            {
                MetroCardRechargeAPI.Models.RechargeModel recharge = new MetroCardRechargeAPI.Models.RechargeModel()
                {
                    Mobile = userModel.UserMobile,
                    ExpiryFrom = DateTime.Now,
                    ExpiryTo = DateTime.Now.AddDays(90),
                    PaymentAmt = rechargeAmt,
                };
                Set("recharge", JsonConvert.SerializeObject(recharge), 10);

                RequestDetails request = new RequestDetails()
                {
                    USERNAME = userModel.UserName,
                    USERMOBILE = userModel.UserMobile,
                    AMOUNT = Convert.ToString(rechargeAmt),
                    USEREMAIL = userModel.UserMail,
                    PURPOSE = CommonValues.Purpose
                };
                TempData["data"] = JsonConvert.SerializeObject(request);
            }
            return View();
        }


        /// <summary>  
        /// Get the cookie  
        /// </summary>  
        /// <param name="key">Key </param>  
        /// <returns>string value</returns>  
        public string Get(string key)
        {
            return Request.Cookies[key];
        }
        /// <summary>  
        /// set the cookie  
        /// </summary>  
        /// <param name="key">key (unique indentifier)</param>  
        /// <param name="value">value to store in cookie object</param>  
        /// <param name="expireTime">expiration time</param>  
        public void Set(string key, string value, int? expireTime)
        {
            CookieOptions option = new CookieOptions();
            if (expireTime.HasValue)
                option.Expires = DateTime.Now.AddMinutes(expireTime.Value);
            else
                option.Expires = DateTime.Now.AddMilliseconds(10);
            Response.Cookies.Append(key, value, option);
        }
        /// <summary>  
        /// Delete the key  
        /// </summary>  
        /// <param name="key">Key</param>  
        public void Remove(string key)
        {
            Response.Cookies.Delete(key);
        }
    }
}

