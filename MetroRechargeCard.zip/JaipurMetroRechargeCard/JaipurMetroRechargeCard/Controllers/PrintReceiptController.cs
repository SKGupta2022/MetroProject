﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JaipurMetroRechardCard.Controllers
{
    public class PrintReceiptController : BaseController
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
