﻿using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using static JaipurMetroRechardCard.Models.Payment;

namespace JaipurMetroRechardCard.Models
{
    public class InvoiceParameter
    {
        [Display(Name = "Status")]
        public string Status { get; set; }
        public string UserName { get; set; }
        public string UserMobile { get; set; }
        public string UserMail { get; set; }
        public string Purpose { get; set; }
        public int Amount { get; set; }
        public int Tax { get; set; }
        public int TotalInvoice { get; set; }
        public Adddress address { get; set; }
        public RechargeDetails rechargeDetails { get; set; }
        public ResponeParameter responseParameter { get; set; }
    }
}
