﻿using MetroCardRechargeAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace JaipurMetroRechardCard.Common
{
    //public class Utility
    //{
    //    public string GetMobile()
    //    {
    //        string cookiedata = Get("User");
    //        string mobile = "";
    //        UserModel userModel = new UserModel();
    //        if (cookiedata != null)
    //        {
    //            userModel = JsonConvert.DeserializeObject<UserModel>(cookiedata);
    //        }

    //        if (userModel != null)
    //        {
    //            MetroCardRechargeAPI.Models.RechargeModel recharge = new MetroCardRechargeAPI.Models.RechargeModel()
    //            {
    //                Mobile = userModel.UserMobile,
    //            };
    //            mobile = recharge.Mobile;
    //        }
    //        return mobile;
    //    }

    //    public string Get(string key)
    //    {
    //        return  Request.Cookies[key];
    //    }
    //}
}
