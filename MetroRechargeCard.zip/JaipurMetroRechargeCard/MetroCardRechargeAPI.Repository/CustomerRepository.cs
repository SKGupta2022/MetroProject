﻿using Dapper;
using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Framework;
using MetroCardRechargeAPI.Interface.Repository;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Net;
using static MetroCardRechargeAPI.Common.SystemMessagesHelper;

namespace MetroCardRechargeAPI.Repository
{
    public class CustomerRepository : AsyncDbRepository, ICustomerRepository
    {
        private readonly IAppSettings _configuration;
        public CustomerRepository(IAppSettings configuration, IDbConnectionFactory connectionFactory) : base(connectionFactory)
        {
            _configuration = configuration;
            if (connectionFactory == null) throw new ArgumentNullException(nameof(connectionFactory));
        }

        public async Task<List<UserDetails>> GetAllCustomer()
        {
            List<UserDetails> returnValue = new List<UserDetails>();
            try
            {
                var queryParameters = new DynamicParameters();
                queryParameters.Add("@Action", CommonAction.Get);
                returnValue = (await WithConnection(async c => await c.QueryAsync<UserDetails>(StoredProcedures.Get_Customer, queryParameters, commandType: CommandType.StoredProcedure))).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return returnValue;
        }

        public async Task<ApiResponse<UserDetails>> GetCustomer(LoginModel login)
        {
            var returnvalue = new UserDetails();
            UserDetails userDetail = new UserDetails();
            List<PaymentDetails> paymentDetails = new List<PaymentDetails>();
            CardDetails cardDetails = new CardDetails();

            ApiResponse<UserDetails> result = null;
            try
            {
                var queryParameters = new DynamicParameters();

                // user details
                queryParameters.Add("@Action", "CustomerDetails");
                queryParameters.Add("@Mobile", login.Mobile);
                userDetail = (await WithConnection(async c => await c.QueryAsync<UserDetails>(StoredProcedures.Get_Customer, queryParameters, commandType: CommandType.StoredProcedure))).FirstOrDefault();

                // recharge details
                queryParameters.Add("@Action", "RechargeDetails");
                queryParameters.Add("@Mobile", login.Mobile);
                paymentDetails = (await WithConnection(async c => await c.QueryAsync<PaymentDetails>(StoredProcedures.RechargeDetails, queryParameters, commandType: CommandType.StoredProcedure))).ToList();

                //CardDetails
                queryParameters.Add("@Action", "CardInfo");
                queryParameters.Add("@Mobile", login.Mobile);
                cardDetails = (await WithConnection(async c => await c.QueryAsync<CardDetails>(StoredProcedures.CardDetails, queryParameters, commandType: CommandType.StoredProcedure))).FirstOrDefault();

                if (paymentDetails != null)
                    userDetail.RechargePaymentLst = paymentDetails;

                if (cardDetails == null)
                {
                    cardDetails = new CardDetails
                    {
                         CardNo="-",
                          PendingAmt=0,
                    };
                }
                userDetail.cardDetails = cardDetails;


                result = new ApiResponse<UserDetails>(HttpStatusCode.OK, Functions.Success, SystemMessagesHelper.GetMessage(SystemMessages.Success), userDetail);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public async Task<ApiResponse<TransactionResponse>> PostCustomer(UserDetails user)
        {
            ApiResponse<TransactionResponse> result = null;
            try
            {
                var queryParameters = new DynamicParameters();
                queryParameters.Add("@Name", user.Name);
                queryParameters.Add("@Address", user.Address);
                queryParameters.Add("@Mobile", user.Mobile);
                queryParameters.Add("@EmailId", user.Email);
                queryParameters.Add("@City", user.City);
                queryParameters.Add("@State", user.State);
                queryParameters.Add("@CreatedBy", "skg");
                queryParameters.Add("@passwrd", user.Password);
                queryParameters.Add("@Pincode   ", user.Pincode);

                var returnvalue = (await WithConnection(async c => await c.QueryAsync<TransactionResponse>(StoredProcedures.Post_Customer, queryParameters, commandType: CommandType.StoredProcedure))).FirstOrDefault();
                result = new ApiResponse<TransactionResponse>(HttpStatusCode.OK, Functions.Success, SystemMessagesHelper.GetMessage(SystemMessages.Success), returnvalue);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }


    }
}

