﻿using Dapper;
using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Framework;
using MetroCardRechargeAPI.Interface.Repository;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static MetroCardRechargeAPI.Common.SystemMessagesHelper;
using System.Linq;

namespace MetroCardRechargeAPI.Repository
{
    public class RechargeRepository : AsyncDbRepository, IRechargeRepository
    {
        private readonly IAppSettings _configuration;
        public RechargeRepository(IAppSettings configuration, IDbConnectionFactory connectionFactory) : base(connectionFactory)
        {
            _configuration = configuration;
            if (connectionFactory == null) throw new ArgumentNullException(nameof(connectionFactory));
        }

        public async Task<ApiResponse<CardDetails>> GetPendingAmount(string mobile)
        {
            CardDetails cardDetails = new CardDetails();
            ApiResponse<CardDetails> result = null;
            var queryParameters = new DynamicParameters();
            try
            {
                queryParameters.Add("@Action", "CardInfo");
                queryParameters.Add("@Mobile", mobile);
                cardDetails = (await WithConnection(async c => await c.QueryAsync<CardDetails>(StoredProcedures.CardDetails, queryParameters, commandType: CommandType.StoredProcedure))).FirstOrDefault();
                result = new ApiResponse<CardDetails>(HttpStatusCode.OK, Functions.Success, SystemMessagesHelper.GetMessage(SystemMessages.Success), cardDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
    }
}
