﻿using Dapper;
using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Framework;
using MetroCardRechargeAPI.Interface.Repository;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Net;
using static MetroCardRechargeAPI.Common.SystemMessagesHelper;
using System.Net.NetworkInformation;
using System.Xml;
using Newtonsoft.Json;
using System.Net.Http;
using System.Xml.Serialization;
using System.IO;
using System.Xml.Linq;

namespace MetroCardRechargeAPI.Repository
{
    public class LoginRepository : AsyncDbRepository, ILoginRepository
    {
        private readonly IAppSettings _configuration;
        public LoginRepository(IAppSettings configuration, IDbConnectionFactory connectionFactory) : base(connectionFactory)
        {
            _configuration = configuration;
            if (connectionFactory == null) throw new ArgumentNullException(nameof(connectionFactory));
        }

        #region Aadhar_Otp_Generation and Verification
        public async Task<OTP_Generate> Aadhar_Otp_Generate(string Aadhaar)
        {
            OTP_Generate otp_generate = new OTP_Generate();
                var TxnOTP = string.Empty;
                var MAC = GetMACAddress();
                IPAddress[] localIPs = Dns.GetHostAddresses(Dns.GetHostName());
                string IP = localIPs[1].ToString();
                try
                {
                    string authXML = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?><authrequest uid='" + Aadhaar + "' appname = '" + Constants.ECARD.appname + "' ver='2.5' subaua='" + Constants.ECARD.SUBAUA + "' ip='" + IP + "' rc='y' bt='otp' fdc='NA' idc='NA' macadd='" + MAC + "' lot='P' lov='110002' lk='" + Constants.ECARD.strlk + "' ><otp channel='01'/></authrequest>";
                    string authURL = Constants.ECARD.authURL1;//"https://api.sewadwaar.rajasthan.gov.in/app/live/was/otp/request/prod?client_id=9063b7b2-3a8d-4efb-8422-0572fff44ab2";//WAS Prod          
                    string response = Functions.postXMLData(authURL, authXML);


                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(response);
                    foreach (XmlNode node in xml.SelectNodes("//auth[@txn]"))
                    {
                        otp_generate.txnID = node.Attributes["txn"].Value;
                    }
                    otp_generate.AadhaarId = Aadhaar;
                    otp_generate.TransactionID = DateTime.Now.ToString(StaticValues.timestamp);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                //otp_generate.txnID = TxnOTP;           
                return otp_generate;
        }

        public async Task<ApiResponse<TransactionResponse>> UserValidate(LoginModel login)
        {
            ApiResponse<TransactionResponse> respones = null;
            var returnvalue = new TransactionResponse();
            try
            {
                var queryParameters = new DynamicParameters();
                queryParameters.Add("@Action", "VerifyUser");
                queryParameters.Add("@Mobile", login.Mobile);
                queryParameters.Add("@Passwrd", login.Passwrd);
                returnvalue = (await WithConnection(async c => await c.QueryAsync<TransactionResponse>(StoredProcedures.LoginVerify, queryParameters, commandType: CommandType.StoredProcedure))).FirstOrDefault();
                respones = new ApiResponse<TransactionResponse>(HttpStatusCode.OK, Functions.Success, SystemMessagesHelper.GetMessage(SystemMessages.Success), returnvalue);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return respones;
        }

        public async Task<OTP_Generate> Aadhar_OTP_Authenticate(OtpAuthenticationParameter otpPara)
        {
            var JanAadhaarId = otpPara.JanAadhaar;
            OTP_Generate janaadhaarotpauth = new OTP_Generate();
            IPAddress[] localIPs = Dns.GetHostAddresses(Dns.GetHostName());
            string IP = localIPs[1].ToString();
            var pdfbase64 = string.Empty;
            var tts = DateTime.Now.ToString("yyyy-MM-ddTHH\\:mm\\:ss");
            string msg = "<Pid ts=\"" + tts + "\" ver=\"2.0\" wadh=\"" + Constants.ECARD.WADH + "\"><Pv otp=\"" + otpPara.Userotp + "\" /></Pid>";
            var pfr = "N";
            string expiryDate = string.Empty;
            string encSessionKey = string.Empty;
            string encryptedHmacBytes = string.Empty;
            string message = string.Empty;
            string encXMLPIDDataNew = callfunction.GetEncryptedPIDXmlNew(msg, tts, ref expiryDate, ref encSessionKey, ref encryptedHmacBytes);
            try
            {
                string authXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><authrequest uid=\"" + otpPara.AadhaarID + "\" appname=\"Emitra+\" tid=\"\" subaua=\"PMITR22855\" bt=\"OTP\" lk=\"" + Constants.ECARD.strlk + "\" ra=\"O\" rc=\"Y\" lr=\"Y\" de=\"N\" pfr=\"" + pfr + "\" mec=\"Y\" ver=\"2.5\" txn=\"" + otpPara.txnid + "\" dpID=\"\" rdsID=\"\" rdsVer=\"\" dc=\"\" mi=\"\" mc=\"\" deviceSrNO=\"NA\" deviceError=\"NA\" ip=\"NA\" fdc=\"NA\" idc=\"NC\" macadd=\"NA\" lot=\"P\" lov=\"302005\" ><deviceInfo fType=\"NA\" iCount=\"NA\" pCount=\"NA\" errCodeRDS=\"NA\" errInfoRDS=\"NA\" fCount=\"NA\" nmPoints=\"NA\" qScore=\"NA\" srno=\"NA\" deviceError=\"NA\" /><Skey ci=\"" + expiryDate + "\">" + encSessionKey + "</Skey><Hmac>" + encryptedHmacBytes + "</Hmac><Data type=\"X\">" + encXMLPIDDataNew + "</Data></authrequest>";
                string responsedata = Functions.postXMLData(Constants.ECARD.authURL, authXML);
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(responsedata);
                string ret = string.Empty;
                foreach (XmlNode node in xml.SelectNodes("//auth[@status]"))
                {
                    ret = node.Attributes["status"].Value;
                }
                if (ret.ToUpper() == "Y")
                {
                    var requesturl = Functions.PostHTTPData(Constants.ECARD.url + otpPara.JanAadhaar + Constants.ECARD.param2, null);
                    var ObjData = JsonConvert.DeserializeObject<JanAadhaarResponse>(requesturl);
                    janaadhaarotpauth.Basestring = ObjData.ecard;
                    janaadhaarotpauth.Message = "200";
                }
                else
                {
                    janaadhaarotpauth.Message = "204";
                }
                janaadhaarotpauth.JanAadhaarId = otpPara.JanAadhaar;
                //janaadhaarotpauth.DepartmentCommission = Constants.ECARD.AadhaarJanAadhaarAmount;
                //janaadhaarotpauth.EmitraCommission = Constants.ECARD.AadhaarJanAadhaarEmitraCommission;
                //janaadhaarotpauth.Amount = Convert.ToInt32(janaadhaarotpauth.DepartmentCommission) + Convert.ToInt32(janaadhaarotpauth.EmitraCommission);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //janaadhaarotpauth.Basestring = janaadhaarotpauth.Basestring;
            //janaadhaarotpauth.Message = message;                       
            return janaadhaarotpauth;
        }
       
        public string GetMACAddress()
        {
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            String sMacAddress = string.Empty;
            foreach (NetworkInterface adapter in nics)
            {
                if (sMacAddress == String.Empty)// only return MAC Address from first card  
                {
                    IPInterfaceProperties properties = adapter.GetIPProperties();
                    sMacAddress = adapter.GetPhysicalAddress().ToString();
                }
            }
            return sMacAddress;
        }
        #endregion

        #region Mobile Otp Generation 
        public async Task<OTPResponseModel> GenerateOTP(OTPRequestModel oTPRequestModel)
        {
            string api = "https://api.sewadwaar.rajasthan.gov.in/app/live/Janaadhaar/Prod/Service/Gen/Otp/For?client_id=189a0b97-e3c8-4a01-8d9a-3f2f2d067f3b";
            OTPRequest oTPRequest = new OTPRequest();
            oTPRequest.OTPRequestModel = oTPRequestModel;
            string xml = LoginRepository.ToXML(oTPRequest);
            xml = RemoveAllNamespaces(xml);
            xml = xml.Replace("OTPRequestModel", "genOtpFor");

            Uri u = new Uri(api);
            var payload = xml;
            HttpContent c = new StringContent(payload, Encoding.UTF8, "application/xml");



            var result = await WebClientAPICall.PostURI(u, c);
            //var resultdata = result;

            result = result.Replace("root", "OTPResponseModel");
            OTPResponseModel oTPResponseModel = new OTPResponseModel();
            var apiResponse = LoginRepository.XMLToObject(result, oTPResponseModel);
            return oTPResponseModel = (OTPResponseModel)apiResponse;
            //return oTPResponseModel = apiResponse;
        }

        public static string ToXML(Object oObject)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlSerializer xmlSerializer = new XmlSerializer(oObject.GetType());
            using (MemoryStream xmlStream = new MemoryStream())
            {
                xmlSerializer.Serialize(xmlStream, oObject);
                xmlStream.Position = 0;
                xmlDoc.Load(xmlStream);
                return xmlDoc.InnerXml;
            }
        }

        public static string RemoveAllNamespaces(string xmlDocument)
        {
            XElement xmlDocumentWithoutNs = RemoveAllNamespaces(XElement.Parse(xmlDocument));

            return xmlDocumentWithoutNs.ToString();
        }

        //Core recursion function
        private static XElement RemoveAllNamespaces(XElement xmlDocument)
        {
            if (!xmlDocument.HasElements)
            {
                XElement xElement = new XElement(xmlDocument.Name.LocalName);
                xElement.Value = xmlDocument.Value;

                foreach (XAttribute attribute in xmlDocument.Attributes())
                    xElement.Add(attribute);

                return xElement;
            }
            return new XElement(xmlDocument.Name.LocalName, xmlDocument.Elements().Select(el => RemoveAllNamespaces(el)));
        }

        public static Object XMLToObject(string XMLString, Object oObject)
        {

            XmlSerializer oXmlSerializer = new XmlSerializer(oObject.GetType());
            oObject = oXmlSerializer.Deserialize(new StringReader(XMLString));
            return oObject;
        }

        public static async Task<string> PostURI(Uri u, HttpContent c)
        {
            var response = string.Empty;
            using (var client = new HttpClient())
            {
                HttpRequestMessage request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = u,
                    Content = c
                };

                HttpResponseMessage result = await client.SendAsync(request);
                var responseContent = await result.Content.ReadAsStringAsync();
                response = responseContent;
            }
            return response;
        }

        #endregion

        #region Mobile Otp Verification

        #endregion

    }
}
