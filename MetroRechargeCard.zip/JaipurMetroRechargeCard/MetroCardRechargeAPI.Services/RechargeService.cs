﻿using MetroCardRechargeAPI.Common;
using MetroCardRechargeAPI.Interface.Repository;
using MetroCardRechargeAPI.Interface.Services;
using MetroCardRechargeAPI.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Services
{
    public class RechargeService : IRechargeService
    {
        IRechargeRepository _rechargeRepository;
        public RechargeService(IRechargeRepository rechargeRepository)
        {
            _rechargeRepository = rechargeRepository;
        }

        public async Task<ApiResponse<CardDetails>> GetPendingAmount(string mobile)
        {
            return await _rechargeRepository.GetPendingAmount(mobile);
        }

    }
}
