﻿using MetroCardRechargeAPI.Interface.Repository;
using MetroCardRechargeAPI.Interface.Services;
using MetroCardRechargeAPI.Models;
using MetroCardRechargeAPI.Common;
using System.Threading.Tasks;

namespace MetroCardRechargeAPI.Services
{
    public class LoginService : ILoginService
    {
        private readonly ILoginRepository loginRepository = null;
        public LoginService(ILoginRepository _loginRepository)
        {
            loginRepository = _loginRepository;
        }

        public async Task<OTP_Generate> Aadhar_OTP_Authenticate(OtpAuthenticationParameter otpPara)
        {
            return await loginRepository.Aadhar_OTP_Authenticate(otpPara);
        }

        public async Task<OTP_Generate> Aadhar_Otp_Generate(string Aadhaar)
        {
            return await loginRepository.Aadhar_Otp_Generate(Aadhaar);
        }

        public async Task<ApiResponse<TransactionResponse>> UserValidate(LoginModel login)
        {
            return await loginRepository.UserValidate(login);
        }
    }
}
